unfinished api wrapper for panelyz
